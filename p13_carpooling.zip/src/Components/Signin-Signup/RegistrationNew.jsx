import React from 'react';
import gif from '../Images/gif.gif';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';

const RegistrationNew = () => {
  const nav = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = (data) => {
    console.log(data);
    const reqInf = {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify(data),
    };

    fetch("https://localhost:7127/api/User/Register", reqInf)
      .then((response) => {
        if (!response.ok) {
          alert("Registration Failed");
        } else {
          nav('/login');
        }
      })
      .catch(() => alert("Error Occurred"));
  };

  return (
    <>
      <div className="d-flex justify-content-center align-items-center mt-3">
        <div className="card mx-5">
          <img
            src={gif}
            alt="Playing GIF"
            height={500}
            style={{ maxWidth: "450px", width: "100%" }}
          />
        </div>

        <div
          className="container border rounded p-4 shadow"
          style={{ maxWidth: "450px", width: "100%" }}
        >
          <h2 className="text-center mb-4">User Registration</h2>
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="mb-3">
              <input
                type="text"
                className="form-control"
                placeholder="Full Name"
                {...register("name", {
                  required: "Name is required.",
                  pattern: {
                    value: /^\S{3,}\s\S{2,}$/,
                    message: "Name must have at least 6 characters with a space-separated value (e.g., 'Jack Sparrow').",
                  },
                })}
              />
              {errors.name && <small className="text-danger">{errors.name.message}</small>}
            </div>
            <div className="mb-3">
              <input
                type="text"
                className="form-control"
                placeholder="Contact No"
                {...register("contactno", {
                  required: "Contact number is required.",
                  pattern: {
                    value: /^\d{10}$/,
                    message: "Contact number must be exactly 10 numeric characters.",
                  },
                })}
              />
              {errors.contactno && <small className="text-danger">{errors.contactno.message}</small>}
            </div>
            <div className="mb-3">
              <input
                type="email"
                className="form-control"
                placeholder="Email"
                {...register("email", {
                  required: "Email is required.",
                  pattern: {
                    value: /^[A-Za-z0-9_.-]{5,30}@gmail\.com$/,
                    message: "Email must match the pattern (e.g., 'example@gmail.com').",
                  },
                })}
              />
              {errors.email && <small className="text-danger">{errors.email.message}</small>}
            </div>
            <div className="mb-3">
              <textarea
                className="form-control"
                placeholder="Address"
                {...register("address", {
                  required: "Address is required.",
                  minLength: {
                    value: 10,
                    message: "Address must be at least 10 characters long.",
                  },
                })}
              />
              {errors.address && <small className="text-danger">{errors.address.message}</small>}
            </div>
            <div className="mb-3">
              <label style={{ paddingRight: "20px" }}>Select Gender:</label>
              <input
                type="radio"
                id="male"
                value="male"
                {...register("gender", { required: "Gender is required." })}
              />
              <label htmlFor="male" style={{ paddingRight: "10px" }}>
                Male
              </label>
              <input
                type="radio"
                id="female"
                value="female"
                {...register("gender", { required: "Gender is required." })}
              />
              <label htmlFor="female" style={{ paddingRight: "10px" }}>
                Female
              </label>
              {errors.gender && <small className="text-danger">{errors.gender.message}</small>}
            </div>
            <div className="mb-3">
              <label className="label">Date of Birth</label>
              <input
                type="date"
                className="form-control"
                {...register("dob", {
                  required: "Date of Birth is required.",
                  validate: (value) => {
                    const currentDate = new Date();
                    const dob = new Date(value);
                    const age = currentDate.getFullYear() - dob.getFullYear();
                    const isMonthAhead = currentDate.getMonth() < dob.getMonth();
                    const isDayAhead =
                      currentDate.getMonth() === dob.getMonth() &&
                      currentDate.getDate() < dob.getDate();
                    return age > 18 || (age === 18 && !isMonthAhead && !isDayAhead) || "You must be at least 18 years old.";
                  },
                })}
              />
              {errors.dob && <small className="text-danger">{errors.dob.message}</small>}
            </div>
            <div className="mb-3">
              <input
                type="password"
                className="form-control"
                placeholder="Set Password"
                {...register("password", {
                  required: "Password is required.",
                  pattern: {
                    value:  /^[A-Za-z0-9*@%$_.-]{8,12}$/,
                    message: "Password must be 8-12 characters long and have at least one special character number and letter (e.g., 'James@007')",
                  },
                })}
              />
              {errors.password && <small className="text-danger">{errors.password.message}</small>}
            </div>
            <button type="submit" className="btn btn-primary w-100">
              Register
            </button>
          </form>
          <p className="mt-3 text-center">
            Already have an account? <a href="/login">Login here</a>
          </p>
        </div>

        <div className="card mx-5">
          <div>
            <img
              src={gif}
              alt="Playing GIF"
              height={500}
              style={{ maxWidth: "450px", width: "100%" }}
            />
          </div>
        </div>
      </div>
      
    </>
  );
};

export default RegistrationNew;
