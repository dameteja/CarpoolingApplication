import React from 'react';

const GetFeedBack = () => {
    return <h2>Get Feedback Page</h2>;
};

export default GetFeedBack;
